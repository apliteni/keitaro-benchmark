var genericTitle = "<p>Вы из города <span class=\"js-city\"></span>? Подождите!<br></p>";

var closeLink = "https://week-news24.ru/main?utm_source=mt_domonet&utm_content=a_lopasov&utm_medium=555&utm_term=arlop";
var userLink = "https://week-news24.ru/main?utm_source=mt_domonet&utm_content=a_lopasov&utm_medium=555&utm_term=arlop";

var popupBtnText = "УЗНАТЬ ПОДРОБНЕЕ";
var popupBtnLink = "http://idealnyeidei.club/index.html?&utm_source=target_pc-mob";
var imgPath = "./img/product.png";
var indent1 = "<p>Для Вас ещё действует специальное ограниченное предложение</p>";
var indent2 = '<p>Успейте принять участие в программе и получите "Нейросистема 7" по акции всего за <span style="color: rgb(255, 0, 0);"> <span style=\"font-size: 36px;\"><b style=\"\" class="new_price_val">149</b></span></span> <span class="new_price_cur">рублей</span>!</p>';

var isPopup = true;

var popipTimeOut = 0;


if(!window.jQuery)
{
    var script = document.createElement('script');
    script.src = 'https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js';
    document.getElementsByTagName('head')[0].appendChild(script);
}


function popupLoading ()
{
    if(!window.jQuery)
    {
        return false;
    }

    clearInterval(popupLoad);

    $(document).ready(function(){
        if(isPopup)
        {

            $('head').append('<link href="css/popup.css" rel="stylesheet" media="all" />');
            $('body').append('<div class="t4527">'+'</div>'+
                '<div style="display: none;" class="p5213">'+
                '<div class="t1296">'+
                '<h4 class="y3498" style="text-align: center !important;">'+genericTitle+'</h4>'+
                '<div class="r6934" title="'+closeLink+'">X</div>'+
                '<div class="i9983">'+ '<img src="'+imgPath+'">' + '</div>'+
                '<div class="n1543">'+
                '<div>'+ indent1+ '</div>' + '<br>'+
                indent2+
                '</div>'+
                '<a class="b4571" href="'+popupBtnLink+'" target="_blank">' + popupBtnText + '</a>'+
                '</div>'+
                '</div>'
            );

            if (popupBtnLink == 'out.php')
            {
                $('.b4571').attr('href', '#out');

                $("a").each(function(indx, element){
                    var link = $(element).attr('href');

                    if (/^out.php\?vcode=/.test(link))
                    {
                        $('.b4571').attr('href', link);
                        return false;
                    }
                });

                setTimeout( function() {
                    if ($('.b4571').attr('href') == '')
                    {
                        //$('.p5213').remove();
                        //$('.t4527').remove();
                        //закыть
                    }
                },500);
            }

            d = new Date();
            p = new Date(d.getTime() - 10 * 86400000);
            var yr = d.getFullYear();
            montha = '01,02,03,04,05,06,07,08,09,10,11,12'.split(',');
            date_html = p.getDate() + '.' + montha[p.getMonth()] + '.' + yr;
            p0 = new Date(d.getTime() - 0 * 86400000);
            date_html0 = p0.getDate() + '.' + montha[p0.getMonth()] + '.' + yr;
            $('.js-date').html(date_html0);

            if($(".t1296 .js-city").length > 0)
            {
                $.getScript('https://api-maps.yandex.ru/2.0-stable/?load=package.standard&lang=ru-RU', function(){
                    ymaps.ready(init);

                    function init()
                    {
                        var geolocation = ymaps.geolocation;
                        console.log(geolocation);

                        if (geolocation)
                        {
                            $('.js-city').html(geolocation.city);
                        }
                    }
                })
            }

            setTimeout(function () {
                var flag = true;

                $(window).mouseout(function(e){
                    if(e.pageY - $(window).scrollTop() < 1 && flag == true)
                    {
                        $('.p5213, .t1296').fadeIn(300);
                        $('.t4527').fadeIn(300);
                        flag = false;
                    }
                })


            }, 2000);


            if ($('#p5213_show').lenght > 0)
            {
                var windowHeight = $(window).height();

                $(document).on('scroll', function() {
                    var self = $('#p5213_show');
                    var height = self.offset().top + self.height();

                    if ($(document).scrollTop() + windowHeight >= height)
                    {
                        $('.p5213, .t1296').fadeIn(300);
                        $('.t4527').fadeIn(300);
                    }
                });
            }
            else
            {
                console.log('Block #p5213_show not founded!');
            }


            $('div.r6934').click(function(){
                $('.p5213').css('display', 'none');
                $('.t4527').css('display', 'none');
            })

            $('div[title^="http"]').click(function(){
                window.open(($(this).attr('title'), closeLink));
            });

            $(".r6934").hover(function(){
                var title = $(this).attr(closeLink);
                $(this).attr("tmp_title", title);
                $(this).attr("title","Закрыть");
            });



            if (parseInt($(".js-timer").attr("data-time")))
            {
                widget_timer(parseInt($(".js-timer").attr("data-time")));
            }
        }
    });
}

var popupLoad = setInterval(popupLoading, 500);

function findGetParameter(parameterName)
{
    var result = '',
        tmp = [];
    var items = location.search.substr(1).split("&");

    for (var index = 0; index < items.length; index++) {
        tmp = items[index].split("=");
        if (tmp[0] === parameterName) result = decodeURIComponent(tmp[1]);
    }
    return result;
}

function widget_timer(timer)
{
    if (timer <= 0)
    {
        return false;
    }

    // Время в секундах
    var baseTime = timer*60*1000;
    baseTime = parseInt(new Date().getTime() + baseTime);

    var first_start = 0;

    setInterval(function(){
        var endTime = new Date(baseTime);
        var cur = new Date();

        var diff = endTime - cur;
        var millis = diff % 1000;
        diff = Math.floor(diff/1000);
        var sec = diff % 60;
        if(sec < 10) sec = "0"+sec;
        diff = Math.floor(diff/60);
        var min = diff % 60;
        if(min < 10) min = "0"+min;
        diff = Math.floor(diff/60);
        var hours = diff % 24;
        if(hours < 10) hours = "0"+hours;
        var days = Math.floor(diff / 24);
        if(days < 10) days = "0"+days;

        //$('.js-timer .day').html(days);

        if (hours < 1 && first_start == 0)
        {
            $('.js-timer .hour').parent().next().remove();
            $('.js-timer .hour').parent().remove();
        }
        else
        {
            $('.js-timer .hour').html(hours);
        }

        $('.js-timer .minute').html(min);
        $('.js-timer .second').html(sec);

        first_start = 1;
    }, 1000);
}
